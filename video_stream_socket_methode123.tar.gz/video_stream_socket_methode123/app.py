import random
import cv2
import task
from base64 import b64encode
from flask import Flask, render_template, request
from flask.ext.socketio import SocketIO, emit
from kinect_python import Kinect


app = Flask(__name__)
app.debug = False
app.threaded = True
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)
kinect = Kinect() 


@app.route('/')
def index():
    return render_template('index.html')


@socketio.on('my event', namespace='/test')
def test_message(message):
    Frame = kinect.GetRgb()
    FrameProccessed = kinect.GetDepth()
    value = kinect.ActivityDetect()
    
    #try:
    Success, Jpeg = cv2.imencode('.jpg', Frame) #encode as jpg
    StrOrginal = b64encode(Jpeg) #change that encodes as string
    #print len(StrOrginal)
    #except:
    #    print "Frame not proper"
    try:
        SuccessProccessed, JpegProccessed = cv2.imencode('.jpg', FrameProccessed)
        StrProccessed = b64encode(JpegProccessed)
    except:
	print "Frame proceesed not p0roper"

    emit('my response1',
         {'imageOrginal':StrOrginal,'imageProccessed':StrProccessed,'value':value})

@socketio.on('disconnect', namespace='/test')
def test_disconnect():
    print('Client disconnected')


if __name__ == '__main__':
    socketio.run(app,host='0.0.0.0')
