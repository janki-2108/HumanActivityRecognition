//exicute this function when load this webpage
$(document).ready(function(){ //It exicute when load index.html

//status flag used for start and stop button actions
var status = true;
var TableStatus = 0;
var b1 = document.getElementById('stop'); //included as elemnt with use of id stop is id
var b2 = document.getElementById('start');
var value = document.getElementById('values');


//initialize socket declarations
namespace = '/test';
var socket = io.connect('http://' + document.domain + ':' + location.port + namespace);

//this function call used for initialisation of the function
looping();

//start and stop button button declaration


//stop button action
	b1.onclick = function() {
        status = false; };

	//start butto action
	b2.onclick = function() {
	//which helps solve to double click error of start button
	if (status !== true) {
		status = true;
		looping();
		}};

	//request for server to send data
	function looping(){
		if (status == true) {
                socket.emit('my event', {data:'None'});}}


	socket.on('my response1', function(msg) {
	
        if (msg !== undefined)
        {
		if (msg.imageOrginal !== undefined) {
			var dataURL="data:image/jpeg;base64,"+msg.imageOrginal; //included the conversion format in the string
			document.getElementById("image").src = dataURL; //asign img src
			$('#Image1Msg').hide();
			 }
		else{
			$('#Image1').hide();
			 }
		if (msg.imageProccessed !== undefined) {
			var dataURL="data:image/jpeg;base64,"+msg.imageProccessed;
			document.getElementById("image2").src = dataURL;
			$('#Image2Msg').hide();
			}
		else{
			$('#Image2').hide();
			 }

		value.innerHTML=msg.value;

				looping();
                }
                else{
                    window.alert("No data got from Server")
                }
	});

});
