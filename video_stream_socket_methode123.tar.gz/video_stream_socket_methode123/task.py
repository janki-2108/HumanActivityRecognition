from openni import *
import cv2
from random import sample,randint
import numpy as np

ctx = Context()
ctx.init()
depth = ImageGenerator()
depth.create(ctx)
depth.set_resolution_preset(RES_VGA)
depth.fps = 30

video = cv2.VideoCapture(0)

def GetVideo():
    global video
    ret,Frame = video.read()
    return Frame


def GetProccesedVideo():
    ctx.start_generating_all()
    ctx.wait_any_update_all()
    FrameProcessed=np.fromstring(Image.get_raw_image_map_bgr(), dtype=np.uint8).reshape(480,640,3)
    #FrameProccessed.astype('|S10')
    return FrameProccessed


